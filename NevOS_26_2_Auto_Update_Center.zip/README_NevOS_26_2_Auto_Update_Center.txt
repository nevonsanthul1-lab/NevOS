NevOS 26.2 — Auto Update Center
================================

This update builds on NevOS 26.1 Control Center 2.0 and preserves the existing source and apps. It adds a clearly discoverable Auto Update Center entry and a shortcut in Control Center. The updater UI uses the dark navy/cyan NevOS theme.

Files
-----
- NevOS_26_2_Auto_Update_Center.py: application source
- NevOS_26_2_Auto_Update_Center.zip: source and this README

Set up your own update server
-----------------------------
1. Host a JSON manifest and a matching NevOS Python source file on a server you control. Use HTTPS for both URLs.
2. Open NevOS > Auto Update Center (also available in Control Center 2.0).
3. Paste the HTTPS URL of your manifest and optionally enable “Check automatically when NevOS starts”.
4. Click Save settings, then Check now to test the connection.

Example manifest (save as JSON and replace the example URL/version):
{
  "version": "26.3-Auto-Update-Fix",
  "download_url": "https://your-domain.example/downloads/NevOS.py",
  "notes": "Bug fixes and improvements"
}

Important behavior and safety
-----------------------------
- No website/server is bundled or configured by default. You must supply your own HTTPS manifest URL.
- Manifest responses are limited to 128 KB; update source downloads are limited to 10 MB.
- The downloaded source is parsed for Python syntax and basic NevOS markers before it is staged as `pending_update.py` in the NevOS data folder.
- NevOS asks before downloading. It does not silently replace the currently running source file. Review the staged source, back up your current file, and replace it manually when NevOS is closed. This avoids pretending a running Python script can safely self-replace in every installation.
- This is a basic HTTPS updater, not a cryptographic signature system. HTTPS protects transport, but it does not independently prove that a release was authored by you. Host updates only on a trusted server and keep your hosting credentials secure.
- Automatic checks are silent on startup if the server is unreachable; use Check now for visible errors.

Run
---
Install Python 3 on Windows, then double-click the `.py` file or run `python NevOS_26_2_Auto_Update_Center.py` from a terminal. Tkinter is included with most standard Windows Python installations.

Validation
----------
The source was syntax-compiled and the ZIP archive was integrity-checked after creation. The Tkinter GUI was not manually launched or interactively tested in this environment.
